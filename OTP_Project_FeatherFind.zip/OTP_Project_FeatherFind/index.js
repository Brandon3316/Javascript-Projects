const fs = require('fs')
const express = require('express')
const otplib = require('otplib')
const uuid = require('uuid')
const { JsonDB } = require('node-json-db')
const { Config } = require('node-json-db/dist/lib/JsonDBConfig')

const app = express()

app.use(express.json())

//Create a file path for myDatabase.json
const dbFilePath = './myDatabase.json'

// To check if myDatabase.json exists or not
if (!fs.existsSync(dbFilePath)) {
// If it doesn't exist, it is created
    fs.writeFileSync(dbFilePath, JSON.stringify({}), 'utf8')
    console.log('myDatabase.json file was created')
}

//Jsondb instance is initiated 
const db = new JsonDB(new Config(dbFilePath, true, false, '/'))

app.get('/api', (req, res) => res.json({ message: 'Welcome to OTP Service'})) 

// Register User
app.post('/api/register', (req, res) => {
    const id = uuid.v4()

// Path to store user data with base 32 and generate OTP secret
    try {
        const path = `/user/${id}`
        const temp_secret = otplib.authenticator.generateSecret()
        db.push(path, { id, temp_secret: temp_secret.base32 })

        //Returns userID and OTP secret in response
        res.json({ id, secret: temp_secret.base32 })
    //If error is encountered
    } catch (error) {
        console.log(error)
        res.status(500).json({ message: 'Error generating OTP secret'})
    }
})

//Verify token
app.post('/api/verify', (req,res) => {
    const {token, userID} = req.body

    //Retrieve user data from the database
    try {
        const path = `/user/${userID}`
        const user = db.getData(path)

        //OTP secret is retrieved from base32 string
        const { temp_secret: secret } = user
        //OTP Secret is verified
        const verified = otplib.totp.verify({ secret, encoding: 'base32', token })

        if(verified) {
            //If token is verified, return success response
            res.json({ verified: true })
        } else {
    // If verification fails, then failure is returned
            res.json({ verified: false })
        }
    } catch (error) {
        console.log(error)
        res.status(500).json({ message: 'Error during token verification'})
    }
})

//Start Server
const PORT = process.env.PORT || 5000

app.listen(PORT, () => console.log(`Server running on port ${PORT}`))