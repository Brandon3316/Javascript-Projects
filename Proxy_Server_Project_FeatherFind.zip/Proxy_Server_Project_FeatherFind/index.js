//Functions of the server
const express = require('express')
const cors = require('cors')
const rateLimit = require('express-rate-limit')
const slowDown = require('express-slow-down')
require('dotenv').config()

//Port 
require('dotenv').config()
const PORT = process.env.PORT || 4000

const app = express()

//Rate limit protection
const limiter = rateLimit({
    windowsMs: 30 * 1000,
    max: 100,
    message: 'Too many requests. please try again later.',
    headers: true,
})

const limiterByApiKey = rateLimit({
    keyGenerator: (req) => req.headers['x-api-key'],
    windowsMs: 30 * 1000,
    max: 100,
    message: 'Too many requests from this API key, please try again later.',
})

//Slow down protection
const speedLimiter = slowDown({
    windowsMs: 30 * 1000,
    delayAfter: 1,
    delayMs: (used, req) => {
        const delayAfter = req.slowDown.limit;
        return (used - delayAfter) * 500;
    },
})
//Middleware to enable cors for all routes
app.use(cors())

//Rate limiting is applied globally
app.use(limiter)

//Slow down protection is applied globally
app.use(speedLimiter)


// Routes for API
app.use('/api', require('./routes'))

// Error handling for middleware (Not sure here)
app.use((err, req, res, next) => {
    console.error(err.stack)
    res.status(500).json({ error: 'Something went wrong!'})
})

//Start Server
app.listen(PORT, () => console.log(`Server running on port ${PORT}`))