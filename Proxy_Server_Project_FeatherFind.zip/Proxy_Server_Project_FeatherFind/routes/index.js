//Basis for the routes
const url = require('url')
const express = require('express')
const router = express.Router()
const needle = require('needle')
const apicache = require('apicache')

//API process
const API_BASE_URL = process.env.API_BASE_URL
const API_KEY_NAME = process.env.API_KEY_NAME
const API_KEY_VALUE = process.env.API_KEY_VALUE

let cache = apicache.middleware

router.get('/', cache('1 minutes'), async (req, res) => {
    try{
        // query parameters including API Key and request
        const params = new URLSearchParams({
            [API_KEY_NAME]: API_KEY_VALUE,
            ...url.parse(req.url, true).query,
        })

        // Using needle for API
        const apiRes = await needle('get', `${API_BASE_URL}?${params}`)
        
        //Check for API reponse success
        if(apiRes.statusCode !== 200){

            // API request not OK
            throw new Error(`API request failed with status code: ${apiRes.statusCode}`)
        }

        const data = apiRes.body


    //API request details
        if(process.env.NODE_ENV !== 'production'){
            console.log(`REQUEST: ${API_BASE}?{params}`)
        }

        //API repsense data is sent to the client
        res.status(200).json(data)
    } catch (error) {

        console.error('Error ocurred processing request:', error),

        //Error is handled without the glitches
        res.status(500).json({
            error: 'An error occured while processing the request.',
            message: error.message,
        
        // Used in non-productive envirnents
            stack: process.env.NODE_ENV === 'production' ? null : error.stack,
        })
    }
})

module.exports = router